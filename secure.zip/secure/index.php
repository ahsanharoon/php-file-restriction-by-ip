<?php
require 'header.php';

// below rest scrpt

?>