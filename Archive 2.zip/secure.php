<?php

$file = 'secure/ip.txt';
$message = '';
if(isset($_POST['secure'])){
if(file_put_contents($file , $_POST['secure'])){
$message = 'success';
}else{
	$message = 'failed';
}

}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Title of the document</title>
<style>
	html, body{
		padding:0;
		margin:0;
	}
	div, form, button, textarea{
		display:block;
		position:relative;
	}
.wrapper {
    width: 100%;
    height: 100%;
    padding: 10px;
    border: 10px solid #d0ebef;
}
form textarea {
    width: 95%;
    display: block;
    margin: auto auto 15px auto;
    text-align: left;
    font-size: 20px;
    background-color: white;
    border: 1px solid #f1f1f1;
    padding: 10px;
    resize: none;
}
.wrapper button {
    padding: 5px 10px 5px 10px;
    border: 3px solid #d0ebef;
    font-size: 15px;
}

span.success, span.failed {
    padding: 5px;
    text-align: center;
    color: white;
    background-color: #4CAF50;
    width: 100%;
    display: block;
    margin: 15px auto auto auto;
    font-size: 20px;
}
span.failed {

    background-color: #F44336;

}
	</style>

</head>

<body>
	<div class="wrapper">
<form action="secure.php" method="post">
<textarea name="secure"><?php echo file_get_contents($file);?></textarea>
<button type="submit">Update</button>
<?php
if($message == 'success'){
echo '<span class="success">File updated successfully.</span>';
}elseif($message == 'failed'){
	echo '<span class="failed">File does not exist or may not have permission to write.</span>';
}
	?>
</form>
</div>
</body>

</html>