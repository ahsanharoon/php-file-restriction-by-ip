<?php
error_reporting(0);
$allow = file('ip.txt', FILE_IGNORE_NEW_LINES); //allowed IPs

//$allow = explode("\n", file_get_contents('ip.txt')); //allowed IPs

//$allow = array("192.168.0.38", "192.168.0.66"); //allowed IPs sample
//print_r($allow);
if(!in_array($_SERVER['REMOTE_ADDR'], $allow) && !in_array($_SERVER["HTTP_X_FORWARDED_FOR"], $allow)) {

//    header("Location: http://localhost"); //redirect

echo 'not matched';
    exit();
}




echo 'matched'; 


?>